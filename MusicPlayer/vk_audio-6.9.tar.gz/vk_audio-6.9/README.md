# vk_audio
Модуль на python для работы с аудио вк
github: https://github.com/imartemy1524/vk_audio
### Установка
Установить данный модуль можно через pypi:
```pip install vk_audio```
### Требования 
> python>=3.6


Описание и примеры тут: https://github.com/imartemy1524/vk_audio
