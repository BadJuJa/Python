version = 5.101;
author_url = "https://vk.com/fesh_dragoziy";
from vk_audio_C_FUNC import *
from .vk_audio import *
